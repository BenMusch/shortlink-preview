const titleReplaceStr = 'courseoff - '
const queryUrl = 'https://tranquil-temple-46832.herokuapp.com/professors'
var school = undefined

const handleModify = (e) => {
  if ($(e.target).hasClass('instructor')) loadInstructor(e.target)
}

const getQueryUrl = (schoolName, profName) => {
  return `${queryUrl}?schoolName=${encodeURI(schoolName)}&profName=${encodeURI(profName)}`
}

const buildRatingTag = (profData) => {
  let openTag = `<a class="rmp-rating" target="_blank" href="${profData['url']} " title="${profData['name']}">`
  return `${openTag}${profData['rating']}</a>`
}

const loadInstructor = (targetNode) => {
  if ($(targetNode).hasClass('rmp-loaded')) return
  $(targetNode).addClass('rmp-loaded')

  let profNameRegex = /^(.+), (.+)\./g
  let targetProf = $(targetNode).text()
  let targetProfMatches = profNameRegex.exec(targetProf)
  if (targetProfMatches == null) return

  let profQuery = `${targetProfMatches[2]} ${targetProfMatches[1]}`
  $.get(getQueryUrl(school, profQuery), (res) => {
    $(targetNode).append($(buildRatingTag(res)));
  })
}

$(document).on('DOMNodeInserted', handleModify);
$(document).ready(() => school = $('title').text().replace(titleReplaceStr, ''))
